using System;
using UnityEngine;

namespace MyDefence {
    [Serializable]
    public class Enemies {
        public GameObject[] arr;
    }
}
