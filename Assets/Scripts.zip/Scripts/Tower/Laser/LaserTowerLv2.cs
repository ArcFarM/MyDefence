using System.Collections;
using UnityEngine;

namespace MyDefence {
    public class LaserTowerLv2 : LaserTower {
        private void Start() {
            TowerLevel = 2;
        }
    }
}

