using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

namespace MyDefence {
    public class MGTowerLv2 : Tower {
        private void Start() {
            TowerLevel = 2;
        }
        //MGTower 고유 기능
    }
}

