using System.Collections;
using UnityEngine;

namespace MyDefence {
    public class MissileTowerLv2 : Tower {
        private void Start() {
            TowerLevel = 2;
        }
    }
}

