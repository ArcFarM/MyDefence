using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

namespace MyDefence {
    public class MGTower : Tower {
        //MGTower 고유 기능
        
    }
}

